<script>
window.location.href="https://www.google.com/search?q=<?php
$a = $_GET['search'];
echo $a;
?>&oq=<?php
$a = $_GET['search'];
echo $a;
?>&ie=UTF-8";
</script>
