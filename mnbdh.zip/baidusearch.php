<script>
window.location.href="https://www.baidu.com/s?wd=<?php
$a = $_GET['search'];
echo $a;
?>";
</script>
