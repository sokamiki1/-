<script>
window.location.href="<?php
echo "https://www.bilibili.com/video/av".mt_rand(0,99999999)."/";
?>";
</script>
