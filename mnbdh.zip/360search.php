<script>
window.location.href="https://www.so.com/s?ie=utf-8&q=<?php
$a = $_GET['search'];
echo $a;
?>";
</script>
