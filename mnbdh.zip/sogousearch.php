<script>
window.location.href="https://www.sogou.com/web?query=<?php
$a = $_GET['search'];
echo $a;
?>";
</script>
